﻿namespace vypocetObsahu
{

    public partial class Form1 : Form
    {

        public double vypocetCtverece(double a)
        {
            return a * a;
        }

        public double vypocetKruh(double r)
        {
            return (r * r) * Math.PI;
        }

        public double vypocetObdelnik(double a, double b)
        {
            return a * b;
        }

        public double vypocetTrojuhelnik(double a, double v)
        {
            return (v * a) / 2;
        }

        public double vypocetLichobeznik(double a, double v, double c)
        {
            return ((a + c) * v) / 2;
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                double val = vypocetCtverece(Decimal.ToDouble(numericUpDown2.Value));
                numericUpDown1.Text = val.ToString();
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                double val = vypocetKruh(Decimal.ToDouble(numericUpDown2.Value));
                numericUpDown1.Text = val.ToString();
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                double val = vypocetLichobeznik(Decimal.ToDouble(numericUpDown2.Value), Decimal.ToDouble(numericUpDown4.Value), Decimal.ToDouble(numericUpDown3.Value));
                numericUpDown1.Text = val.ToString();
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                double val = vypocetObdelnik(Decimal.ToDouble(numericUpDown2.Value), Decimal.ToDouble(numericUpDown3.Value));
                numericUpDown1.Text = val.ToString();
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                double val = vypocetTrojuhelnik(Decimal.ToDouble(numericUpDown2.Value), Decimal.ToDouble(numericUpDown3.Value));
                numericUpDown1.Text = val.ToString();
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                // čtverec
                label4.Text = ("a");
                label5.Hide();
                label6.Hide();
                numericUpDown3.Hide();
                numericUpDown4.Hide();

                pictureBox1.Image = Properties.Resources.ctverec;
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                // kruh
                label4.Text = ("r");
                label5.Hide();
                label6.Hide();
                numericUpDown3.Hide();
                numericUpDown4.Hide();

                pictureBox1.Image = Properties.Resources.kruh;
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                // lichoběžník
                label4.Text = ("a");
                label5.Text = ("c");
                label6.Text = ("v");
                label5.Show();
                label6.Show();
                numericUpDown3.Show();
                numericUpDown4.Show();

                pictureBox1.Image = Properties.Resources.lichobeznik;

            }
            else if (comboBox1.SelectedIndex == 3)
            {
                // obdelník
                label4.Text = ("a");
                label5.Text = ("b");
                label5.Show();
                numericUpDown3.Show();
                label6.Hide();
                numericUpDown4.Hide();

                pictureBox1.Image = Properties.Resources.obdelnik;

            }
            else if (comboBox1.SelectedIndex == 4)
            {
                // trojúhelník
                label4.Text = ("a");
                label5.Text = ("v");
                label5.Show();
                numericUpDown3.Show();
                label6.Hide();
                numericUpDown4.Hide();

                pictureBox1.Image = Properties.Resources.trojuhelnik;

            }

            int selectedIndex = comboBox1.SelectedIndex;
            Object selectedItem = comboBox1.SelectedItem;

            if (comboBox1.SelectedIndex >= 0)
            {

            }
            else
            {
                MessageBox.Show("Vyberte tvar.");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add(new KeyValuePair<string, string>("Čtverec", "0"));
            comboBox1.Items.Add(new KeyValuePair<string, string>("Kruh", "1"));
            comboBox1.Items.Add(new KeyValuePair<string, string>("Lichoběžník", "2"));
            comboBox1.Items.Add(new KeyValuePair<string, string>("Obdelník", "3"));
            comboBox1.Items.Add(new KeyValuePair<string, string>("Trojúhelník", "4"));

            comboBox1.DisplayMember = "key";
            comboBox1.ValueMember = "value";
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}